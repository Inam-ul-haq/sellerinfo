<div class="kt-portlet__body ">

    <table class="table table-striped" id="yearly_dashboard_table">
        <thead>
            <tr>
                <th title="Field #7">Product Name</th>
                <th title="Field #3">Quantity</th>
                <th title="Field #4">Sam Quantity</th>
                <th title="Field #5">Sam Price</th>
            </tr>
        </thead>
    </table>
</div>
<?php /**PATH /var/www/html/Hosting/resources/views/dashboard/partials/yearlytable.blade.php ENDPATH**/ ?>