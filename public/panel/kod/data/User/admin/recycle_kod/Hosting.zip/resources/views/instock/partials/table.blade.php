<div class="kt-portlet__body ">

    <table class="table table-striped" id="instock_table">
        <thead>
            <tr>
                <th title="Field #1">url</th>
                <th title="Field #2">Product</th>
                <th title="Field #3">Store</th>
                <th title="Field #4">Status</th>
                <th title="Field #5">Active</th>
                <th title="Field #6">Action</th>
            </tr>
        </thead>

    </table>
</div>
