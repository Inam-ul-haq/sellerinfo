<div class="kt-portlet__body ">

    <table class="table table-striped" id="admin_table">
        <thead>
            <tr>
                <th title="Field #1">Username</th>
                <th title="Field #2">Email</th>
                <th title="Field #3">Join Date</th>
                <th title="Field #4">Action</th>
            </tr>
        </thead>

    </table>
</div>
<?php /**PATH /var/www/html/Hosting/resources/views/admin/partials/table.blade.php ENDPATH**/ ?>