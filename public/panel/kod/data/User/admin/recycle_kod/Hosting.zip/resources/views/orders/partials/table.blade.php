

        <div class="kt-portlet__body ">


                <table class="table table-striped" id="order_table">
                    <thead>
                        <tr>

                            <th title="Field #1">Amazon ID</th>
                            <th title="Field #2">Sam ID</th>
                            <th title="Field #3">Quantity</th>
                            <th title="Field #4">Sam Quantity</th>
                            <th title="Field #5">Sam Price</th>
                            <th title="Field #6">Sam Email</th>
                            <th title="Field #7">Product Name</th>
                            <th title="Field #8">Order Date</th>
                            <th title="Field #9">Action</th>
                        </tr>
                    </thead>

                </table>


        </div>

