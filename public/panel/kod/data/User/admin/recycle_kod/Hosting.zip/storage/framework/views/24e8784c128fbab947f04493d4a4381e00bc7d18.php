<div class="kt-footer  kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-footer__copyright">
            <!-- 2019&nbsp;&copy;&nbsp;<a href="http://keenthemes.com/metronic" target="_blank" class="kt-link">Keenthemes</a> -->

    <span id="copyright">

        <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script>
    </span>
  
        </div>
        <div class="kt-footer__menu">
            <a href="#" target="_blank" class="kt-footer__menu-link kt-link">About</a>
            <a href="#" target="_blank" class="kt-footer__menu-link kt-link">Team</a>
            <a href="#" target="_blank" class="kt-footer__menu-link kt-link">Contact</a>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/Hosting/resources/views/partials/nav/footer.blade.php ENDPATH**/ ?>