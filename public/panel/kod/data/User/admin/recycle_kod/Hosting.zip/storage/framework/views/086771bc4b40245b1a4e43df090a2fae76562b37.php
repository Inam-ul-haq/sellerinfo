<?php $__env->startSection('content'); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="kt-portlet">
        <div class="kt-portlet__head">
            <div class="kt-portlet__head-label">
                <h3 class="kt-portlet__head-title">
                    Change Password
                </h3>
            </div>
        </div>

        <!--begin::Form-->
        <form class="kt-form kt-form--label-right" method="POST" action="<?php echo e(route('changepassword')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="kt-portlet__body">
                <div class="kt-section kt-section--first">
                    <h3 class="kt-section__title">Fill the Form below:</h3>
                    <div class="kt-section__body">
                        <div class="form-group row">
                            <label for="current-password"
                                class="col-lg-3 col-form-label <?php echo e($errors->has('current-password') ? ' has-error' : ''); ?>">Current
                                Password:</label>
                            <div class="col-lg-6">
                                <input type="password" name="current-password" class="form-control"
                                    placeholder="Current passowrd">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="new-password" class="col-lg-3 col-form-label">New Password:</label>
                            <div class="col-lg-6">
                                <input type="password" name="new-password" class="form-control" placeholder="New password">
                            </div>
                        </div>
                        <?php if($errors->has('new-password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('new-password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="kt-section__body">
                        <div class="form-group row">
                            <label for="new-password_confirmation" class="col-lg-3 col-form-label">Confrim New
                                Password:</label>
                            <div class="col-lg-6">
                                <input type="password" name="new-password_confirmation" class="form-control"
                                    placeholder="Confrim new password">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="kt-portlet__foot">
                <div class="kt-form__actions">
                    <div class="row">
                        <div class="col-lg-3"></div>
                        <div class="col-lg-6">
                            <button type="submit" class="btn btn-success">Submit</button>
                            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-secondary" role="button">Cancel</a>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <!--end::Form-->
    </div>





    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Hosting/resources/views/auth/passwords/change.blade.php ENDPATH**/ ?>